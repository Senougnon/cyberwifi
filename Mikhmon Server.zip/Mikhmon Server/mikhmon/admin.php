<?php
/*
 *  Copyright (C) 2018 Laksamadi Guko.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
session_start();
// hide all error
error_reporting(0);

ob_start("ob_gzhandler");

// check url
$url = $_SERVER['REQUEST_URI'];

// load session MikroTik
$session = $_GET['session'];
$id = $_GET['id'];
$c = $_GET['c'];
$router = $_GET['router'];
$logo = $_GET['logo'];

$ids = array(
  "editor",
  "uplogo",
  "settings",
);

// lang
include('./lang/isocodelang.php');
include('./include/lang.php');
include('./lang/'.$langid.'.php');

// quick bt
include('./include/quickbt.php');

// theme
include('./include/theme.php');
include('./settings/settheme.php');
include('./settings/setlang.php');
if ($_SESSION['theme'] == "") {
    $theme = $theme;
    $themecolor = $themecolor;
  } else {
    $theme = $_SESSION['theme'];
    $themecolor = $_SESSION['themecolor'];
}


// load config
include_once('./include/headhtml.php');
?>
<!-- Ajout du CSS pour la modale Firebase -->
<style>
#firebaseAuthOverlay {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0, 0, 0, 0.7);
  z-index: 9998;
  display: flex; /* Use flexbox for centering */
  justify-content: center;
  align-items: center;
  opacity: 1; /* Start visible for initial check */
  transition: opacity 0.3s ease-out;
  pointer-events: auto; /* Allow interaction initially */
}
#firebaseAuthOverlay.hidden {
  opacity: 0;
  pointer-events: none; /* Disable interaction when hidden */
}


#firebaseAuthModal {
  background-color: #fff;
  padding: 30px;
  border-radius: 8px;
  box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
  z-index: 9999;
  display: block; /* Always block when parent is flex */
  min-width: 300px;
  max-width: 90%; /* Prevent overflow on small screens */
  width: 400px;
  text-align: center;
  color: #333;
  opacity: 1; /* Start visible */
  transform: scale(1);
  transition: opacity 0.3s ease-out, transform 0.3s ease-out;
}
#firebaseAuthOverlay.hidden #firebaseAuthModal {
    opacity: 0;
    transform: scale(0.95);
}


#firebaseAuthModal h2 {
  margin-top: 0;
  margin-bottom: 20px;
  color: #555;
}

#firebaseAuthModal label {
  display: block;
  margin-bottom: 5px;
  text-align: left;
  font-weight: bold;
  color: #666;
  font-size: 0.9em; /* Slightly smaller label */
}

#firebaseAuthModal input[type="text"],
#firebaseAuthModal input[type="password"] {
  width: 100%;
  padding: 10px;
  margin-bottom: 15px;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
  font-size: 1em;
}

#firebaseAuthModal button {
  background-color: #007bff;
  color: white;
  padding: 12px 20px;
  border: none;
  border-radius: 5px;
  cursor: pointer;
  font-size: 16px;
  transition: background-color 0.3s ease, opacity 0.3s ease;
  width: 100%; /* Make button full width */
  margin-top: 10px; /* Space above button */
}

#firebaseAuthModal button:hover:not(:disabled) {
  background-color: #0056b3;
}
#firebaseAuthModal button:disabled {
    background-color: #cccccc;
    cursor: not-allowed;
    opacity: 0.7;
}

#firebaseAuthModal .error-message {
    color: #dc3545; /* Bootstrap danger red */
    font-size: 0.9em;
    margin-top: 10px; /* Space above error */
    margin-bottom: 0px; /* Space below error */
    min-height: 1.2em; /* Reserve space */
    display: none; /* Hidden by default */
}
#firebaseAuthModal .error-message.visible {
    display: block;
}


#modifyFirebaseAuthButtonContainer {
    padding: 10px 15px;
    text-align: right;
    position: fixed; /* Keep button visible */
    top: 0;
    right: 0;
    z-index: 100; /* Above content but below modal */
}
#modifyFirebaseAuthButton {
    padding: 8px 15px;
    background-color: #ffc107;
    color: #333;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    font-size: 0.9em;
    transition: background-color 0.3s ease;
}
#modifyFirebaseAuthButton:hover {
    background-color: #e0a800;
}

/* Spinner within button or near it */
.button-loader {
    display: inline-block;
    border: 3px solid #f3f3f3; /* Light grey */
    border-top: 3px solid #3498db; /* Blue */
    border-radius: 50%;
    width: 12px;
    height: 12px;
    animation: spin 1s linear infinite;
    margin-left: 5px;
    vertical-align: middle;
}
@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}

</style>
<?php
include('./include/config.php');
include('./include/readcfg.php');

include_once('./lib/routeros_api.class.php');
include_once('./lib/formatbytesbites.php');

?>
</head>
<body class="hold-transition <?= $theme; ?> sidebar-mini">


<div id="firebaseAuthOverlay" class="hidden"> <!-- Start hidden by default, show with JS -->
    <div id="firebaseAuthModal">
        <h2>Identifiants d'administration</h2>
        <p id="firebaseAuthModalText">Veuillez enregistrer vos identifiants Firebase pour continuer.</p>
        <div id="firebaseAuthError" class="error-message"></div> <!-- Error message area -->
        <div>
            <label for="firebaseUserIdInput">Admin User ID:</label>
            <input type="text" id="firebaseUserIdInput" required autocomplete="username">
        </div>
        <div>
            <label for="firebasePasswordInput">Admin Password:</label>
            <input type="password" id="firebasePasswordInput" required autocomplete="current-password">
        </div>
        <button id="saveFirebaseAuthButton">Continuer</button>
    </div>
</div>

<div class="wrapper">

    <?php

    // Only show the modify button if Mikhmon session exists (PHP login successful)
    // and if the current page is NOT the PHP login page itself
    if (isset($_SESSION["mikhmon"]) && $id !== 'login') {
        echo '<div id="modifyFirebaseAuthButtonContainer">';
        echo '<button id="modifyFirebaseAuthButton"><i class="fa fa-key"></i> Modifier ID admin</button>';
        echo '</div>';
    }


    if ($id == "login" || substr($url, -1) == "p") {

      if (isset($_POST['login'])) {
        $user = $_POST['user'];
        $pass = $_POST['pass'];
        if ($user == $useradm && $pass == decrypt($passadm)) {
          $_SESSION["mikhmon"] = $user;
            echo "<script>window.location='./admin.php?id=sessions'</script>";
            exit();

        } else {
          $error = '<div style="width: 100%; padding:5px 0px 5px 0px; border-radius:5px;" class="bg-danger"><i class="fa fa-ban"></i> Alert!<br>Invalid username or password.</div>';
        }
      }


      include_once('./include/login.php');
    } elseif (!isset($_SESSION["mikhmon"])) {
       // If not logged in via PHP session, and not on the PHP login page, redirect to PHP login
       // This part ensures the standard Mikhmon PHP login is required first
       if ($id !== 'login') {
            echo "<script>window.location='./admin.php?id=login';</script>";
       }
       // If on login page, Firebase modal might be handled by JS (see below)
    } elseif (substr($url, -1) == "/" || substr($url, -4) == ".php") {
       echo "<script>window.location='./admin.php?id=sessions'</script>";
       exit();
    } else {
        include_once('./include/menu.php');

        echo '<div class="content-wrapper"><div class="content">';

        // Include the rest of the admin content based on $id
        // These pages will run *after* the PHP login is successful
        // and the Firebase modal (if shown) is dismissed.
        if ($id == "sessions") {
            $_SESSION["connect"] = "";
            include_once('./settings/sessions.php');

        } elseif ($id == "settings" && (!empty($session) || !empty($router))) {
            include_once('./settings/settings.php');
            echo '
            <script type="text/javascript">
              var sessnameInput = document.getElementById("sessname");
              if (sessnameInput) {
                  sessnameInput.onkeypress = function(e) {
                  var chr = String.fromCharCode(e.which);
                  if (" _!@#$%^&*()+=;|?,~".indexOf(chr) >= 0)
                      return false;
                  };
              }
              </script>';
        } elseif ($id == "connect"  && !empty($session)) {
            ini_set("max_execution_time", 5);
            if (!class_exists('RouterosAPI')) {
                include_once('./lib/routeros_api.class.php');
            }
            $API = new RouterosAPI();
            $API->debug = false;

            if (isset($iphost) && isset($userhost) && isset($passwdhost) && $API->connect($iphost, $userhost, decrypt($passwdhost))){
                $_SESSION["connect"] = "<b class='text-green'>Connected</b>";
                echo "<script>window.location='./?session=" . $session . "'</script>";
                exit();
            } else {
                $_SESSION["connect"] = "<b class='text-red'>Not Connected</b>";
                $nl = '\\n';
                $alertMessage = 'Mikhmon not connected!' . $nl;
                if (isset($currency) && isset($cekindo) && is_array($cekindo) && isset($cekindo['indo']) && in_array($currency, $cekindo['indo'])) {
                    $alertMessage .= 'Silakan periksa kembali IP, User, Password dan port API harus enable.' . $nl . 'Jika menggunakan koneksi VPN, pastikan VPN tersebut terkoneksi.';
                } else {
                    $alertMessage .= 'Please check the IP, User, Password and port API must be enabled.';
                }
                echo "<script>alert('" . addslashes($alertMessage) . "');</script>";

                if($c == "settings"){
                    echo "<script>window.location='./admin.php?id=settings&session=" . $session . "'</script>";
                } else {
                    echo "<script>window.location='./admin.php?id=sessions'</script>";
                }
                exit();
            }
        } elseif ($id == "uplogo"  && !empty($session)) {
            include_once('./settings/uplogo.php');
        } elseif ($id == "reboot"  && !empty($session)) {
            include_once('./process/reboot.php');
        } elseif ($id == "shutdown"  && !empty($session)) {
            include_once('./process/shutdown.php');
        } elseif ($id == "remove-session" && !empty($session)) {
            $configFile = "./include/config.php";
            if (file_exists($configFile) && is_readable($configFile) && is_writable($configFile)) {
                $fc = file($configFile);
                $f = fopen($configFile, "w");
                if ($f) {
                    $q = "'";
                    $rem = '$data['.$q.$session.$q.']';
                    foreach ($fc as $line) {
                        if (strpos($line, $rem) === false) {
                            fputs($f, $line);
                        }
                    }
                    fclose($f);
                    echo "<script>window.location='./admin.php?id=sessions'</script>";
                    exit();
                } else {
                    echo "<p style='color:red; padding:15px;'>Error: Could not open config file for writing.</p>";
                }
            } else {
                 echo "<p style='color:red; padding:15px;'>Error: Config file not found, not readable, or not writable.</p>";
            }
        } elseif ($id == "about") {
            include_once('./include/about.php');
        } elseif ($id == "logout") {
             echo "<div style='padding: 20px; text-align: center;'>";
             echo "<b class='cl-w'><i class='fa fa-circle-o-notch fa-spin' style='font-size:24px'></i> Logout...</b>";
             echo "</div>";
            session_destroy();
            echo "<script>setTimeout(function() { window.location.href='./admin.php?id=login'; }, 1000);</script>";
            exit();
        } elseif ($id == "remove-logo" && !empty($logo)  && !empty($session)) {
            $logopath = "./img/";
            $remlogo = $logopath . basename($logo);
            if (file_exists($remlogo)) {
                if (unlink("$remlogo")) {
                    echo "<script>window.location='./admin.php?id=uplogo&session=" . $session . "'</script>";
                    exit();
                } else {
                     echo "<p style='color:red; padding: 15px;'>Error: Could not remove logo file.</p>";
                     echo "<script>setTimeout(function() { window.location.href='./admin.php?id=uplogo&session=" . $session . "'; }, 3000);</script>";
                }
            } else {
                 echo "<p style='color:red; padding: 15px;'>Error: Logo file not found.</p>";
                  echo "<script>setTimeout(function() { window.location.href='./admin.php?id=uplogo&session=" . $session . "'; }, 3000);</script>";
            }
        } elseif ($id == "editor"  && !empty($session)) {
            include_once('./settings/vouchereditor.php');
        } elseif (empty($id) && isset($_SESSION["mikhmon"])) {
            echo "<script>window.location='./admin.php?id=sessions'</script>";
            exit();
        } elseif(in_array($id, $ids) && empty($session) && isset($_SESSION["mikhmon"])){
        	echo "<script>window.location='./admin.php?id=sessions'</script>";
            exit();
        } else {
             // Fallback if PHP session exists but id is not valid
             if(isset($_SESSION["mikhmon"])){
                 echo "<script>window.location='./admin.php?id=sessions'</script>";
                 exit();
             }
             // If PHP session does NOT exist and id is not 'login', it was handled above by redirect.
             // If PHP session does NOT exist and id *is* 'login', the PHP login form was included.
        }

        echo '</div></div>';
    }

    ?>

</div><!-- ./wrapper -->

<?php include('./include/info.php'); ?>

<!-- JavaScript pour la gestion de la modale Firebase -->
<script type="module">
    // --- Firebase Imports ---
    import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js";
    import { getDatabase, ref, get, set, push, update, goOffline, goOnline } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-database.js";
    // Assuming firebase-config-manager.js handles initialization and returns the DB instance
    import { getActiveDatabase } from './firebase-config-manager.js';

    // --- Global Variables ---
    let db = null; // Will hold the active database instance once initialized

    // --- DOM Element References ---
    const modal = document.getElementById('firebaseAuthModal');
    const overlay = document.getElementById('firebaseAuthOverlay');
    const saveButton = document.getElementById('saveFirebaseAuthButton');
    const userIdInput = document.getElementById('firebaseUserIdInput');
    const passwordInput = document.getElementById('firebasePasswordInput');
    const errorMessageElement = document.getElementById('firebaseAuthError'); // Renamed for clarity
    const modalText = document.getElementById('firebaseAuthModalText');
    const modifyButton = document.getElementById('modifyFirebaseAuthButton');

    // --- Utility Functions ---

    function displayModalError(message) {
        if (errorMessageElement) {
            errorMessageElement.textContent = message;
            errorMessageElement.classList.add('visible');
        }
    }

    function clearModalError() {
        if (errorMessageElement) {
            errorMessageElement.textContent = '';
            errorMessageElement.classList.remove('visible');
        }
    }

    function showModalLoader() {
        if (saveButton) {
            saveButton.disabled = true;
            // Optional: Add a spinner or change text
            saveButton.textContent = 'Vérification...'; // Or add spinner element
        }
    }

    function hideModalLoader() {
        if (saveButton) {
            saveButton.disabled = false;
            saveButton.textContent = 'Continuer'; // Restore original text
            // Optional: Remove spinner
        }
    }

    function showModal(isModification = false) {
        if (!modal || !overlay) return;

        clearModalError(); // Clear errors when showing modal
        hideModalLoader(); // Ensure loader is hidden

        let storedUserId = localStorage.getItem('firebaseUserId');
        let storedPassword = localStorage.getItem('firebasePassword'); // We won't pre-fill password for security

        if (isModification || !storedUserId || storedUserId.trim() === '') {
             userIdInput.value = storedUserId || ''; // Pre-fill username if exists
             passwordInput.value = ''; // Never pre-fill password
             modalText.textContent = "Relier une base de données admin pour la gestion de vos tickets.";
             saveButton.textContent = "Enregistrer et Continuer"; // More descriptive text on first save/modification
         } else {
             userIdInput.value = storedUserId; // Pre-fill username
             passwordInput.value = ''; // Never pre-fill password
             modalText.textContent = "Identifiants Firebase enregistrés. Veuillez entrer le mot de passe pour continuer."; // Ask for password to continue
             saveButton.textContent = "Continuer"; // Action is "Continue" using saved ID
         }

        // Show the modal with fade-in effect
        overlay.classList.remove('hidden');
        document.body.style.overflow = 'hidden'; // Prevent background scroll
    }

    function hideModal() {
        if (!modal || !overlay) return;
        // Hide the modal with fade-out effect
        overlay.classList.add('hidden');
        // Use a small timeout to allow fade-out animation before removing overflow hidden
        overlay.addEventListener('transitionend', function handler() {
             document.body.style.overflow = ''; // Re-enable background scroll
             overlay.removeEventListener('transitionend', handler);
        }, { once: true }); // Ensure the listener is removed after one use
    }


    // --- Firebase Authentication Logic ---

    async function authenticateFirebaseAdmin() {
        clearModalError();
        showModalLoader();

        const userId = userIdInput.value.trim();
        const password = passwordInput.value; // Do not trim password

        if (!userId || !password) {
            displayModalError("Veuillez remplir tous les champs.");
            hideModalLoader();
            return;
        }

        try {
            // Initialize DB if not already done
            if (!db) {
                console.log("Initializing Firebase DB for modal authentication...");
                db = await getActiveDatabase(); // Use the manager to get the correct DB
                 goOnline(db); // Ensure connection is active
                console.log("Firebase DB initialized.");
            }

            // Perform lookup in the 'users' node, just like loginAccueil.html
            const userRef = ref(db, `users/${userId}`);
            console.log(`Checking user: ${userId}`);
            const snapshot = await get(userRef);

            if (snapshot.exists()) {
                const userData = snapshot.val();
                 // WARNING: Plain text password comparison (inherits insecurity from loginAccueil.html structure)
                if (userData.password === password) {
                    console.log("Firebase authentication successful for user:", userId);
                    // Success! Save credentials locally and dismiss modal
                    try {
                        localStorage.setItem('firebaseUserId', userId);
                        localStorage.setItem('firebasePassword', password); // Store plaintext password locally too (STILL INSECURE)
                        console.log("Firebase credentials saved locally.");
                    } catch (e) {
                         console.error("Error saving Firebase credentials to localStorage:", e);
                         displayModalError("Erreur locale: impossible d'enregistrer les identifiants.");
                         // Don't hide modal if localStorage failed, even if auth succeeded
                         hideModalLoader();
                         return;
                    }

                    hideModal(); // Hide the modal, user remains on the current Mikhmon page
                    // No redirect is needed here

                } else {
                    // Incorrect password
                    console.warn("Firebase authentication failed: Incorrect password for user:", userId);
                    displayModalError("ID utilisateur ou mot de passe incorrect.");
                }
            } else {
                // User does not exist
                console.warn("Firebase authentication failed: User not found:", userId);
                displayModalError("ID utilisateur ou mot de passe incorrect.");
            }

        } catch (error) {
            console.error("Error during Firebase authentication:", error);
            displayModalError(`Erreur de connexion Firebase: ${error.message}`);
        } finally {
            hideModalLoader();
            // Optional: Consider going offline with 'db' if not needed elsewhere
            // goOffline(db); // Only if this is the *only* place DB is used
        }
    }


    // --- Page Load and Event Setup ---

    document.addEventListener('DOMContentLoaded', function() {

        // Initial check on page load
        const storedUserId = localStorage.getItem('firebaseUserId');
        const storedPassword = localStorage.getItem('firebasePassword');

        // Only show the modal on load if *no* firebase credentials are saved locally.
        // If they exist, we assume they are valid for initial page view.
        // Validation will only happen when the user clicks 'Continuer' in the modal.
        if (!storedUserId || storedUserId.trim() === '' || !storedPassword || storedPassword.trim() === '') {
            console.log("No Firebase credentials found locally. Showing modal.");
            showModal(false); // Show modal to capture credentials
        } else {
             console.log("Firebase credentials found locally. Hiding modal initially.");
             hideModal(); // Hide modal if credentials exist
        }


        // Setup event listeners AFTER DOM is ready
        if (saveButton) {
            saveButton.addEventListener('click', authenticateFirebaseAdmin);
        }

        if (modifyButton) {
            modifyButton.addEventListener('click', function() {
                // Show the modal again, allowing the user to modify credentials
                showModal(true);
            });
        }

    });
</script>

<script src="js/mikhmon-ui.<?= $theme; ?>.min.js"></script>
<script src="js/mikhmon.js?t=<?= str_replace(" ","_",date("Y-m-d H:i:s")); ?>"></script>


</body>
</html>
<?php
ob_end_flush();
?>