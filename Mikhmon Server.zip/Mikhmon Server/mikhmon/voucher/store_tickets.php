<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

if (!isset($_SESSION["mikhmon"])) {
    header("Location:../admin.php?id=login");
    echo json_encode(['status' => 'error', 'message' => 'Session expired.']);
    exit;
}

require_once('../include/config.php'); // Include your Mikrotik config and firebase-config-manager path

$jsonData = file_get_contents('php://input');
$data = json_decode($jsonData, true);

if (!isset($data['tickets']) || !is_array($data['tickets'])) {
    echo json_encode(['status' => 'error', 'message' => 'Invalid ticket data received.']);
    exit;
}

$tickets = $data['tickets'];

// Path to your firebase-config-manager.js, adjust if necessary based on your file structure
$firebaseConfigManagerPath = '../js/firebase-config-manager.js';

?>

<!DOCTYPE html>
<html>
<head>
    <title>Storing Tickets</title>
</head>
<body>
    <script type="module">
        import { getActiveDatabase } from '<?php echo $firebaseConfigManagerPath; ?>';
        import { ref, push, set } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-database.js";

        async function storeTickets() {
            try {
                const db = await getActiveDatabase();
                const ticketsTotalRef = ref(db, 'users-data/YOUR_USER_ID/TicketsTotal'); // Replace YOUR_USER_ID with the actual user ID dynamically if possible, or hardcode for testing

                const tickets = <?php echo json_encode($tickets); ?>;
                let successCount = 0;

                for (const ticket of tickets) {
                    if (ticket && ticket.username && ticket.password && ticket.profile) {
                        const newTicketRef = push(ticketsTotalRef); // Generate unique ID
                        await set(newTicketRef, {
                            category: ticket.profile, // Or decide on a category logic
                            password: ticket.password,
                            price: ticket->price ?? '0', // Default price if missing
                            user: ticket.username
                            // You can add other relevant fields here if needed
                        });
                        successCount++;
                    }
                }

                if (successCount > 0) {
                    // Send success response back to print.php
                    sendResponse({ status: 'success', message: `${successCount} tickets stored successfully.` });
                } else {
                    // Send error response if no tickets were stored
                    sendResponse({ status: 'error', message: 'No valid tickets to store.' });
                }


            } catch (error) {
                console.error("Error storing tickets in Firebase:", error);
                // Send error response back to print.php
                sendResponse({ status: 'error', message: 'Failed to store tickets: ' + error.message });
            }
        }

        function sendResponse(response) {
            // Send the response back to the PHP caller (print.php)
            window.parent.postMessage(response, '*'); // Or specify origin for security
        }

        storeTickets(); // Call the function to start storing tickets

    </script>
</body>
</html>