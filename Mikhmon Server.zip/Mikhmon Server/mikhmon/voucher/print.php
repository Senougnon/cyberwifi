<?php
/*
 *  Copyright (C) 2018 Laksamadi Guko.
 *  All rights reserved.
 *  Page : print.php
 *  This is the print page for generating Mikrotik Hotspot vouchers.
 *  This page includes integration with Firebase for saving ticket data.
 */
session_start();

error_reporting(0); // Suppress errors (consider using error reporting during development)

ob_start("ob_gzhandler"); // Enable Gzip compression

// Check if user is logged into Mikhmon session
if (!isset($_SESSION["mikhmon"])) {
    header("Location:../admin.php?id=login");
    exit; // Ensure script stops execution after redirect
} else {

    date_default_timezone_set($_SESSION['timezone']);

    // Load session MikroTik details
    $session = $_GET['session']; // Session identifier for logo, etc.

    // Load configuration files
    include('../include/config.php');
    include('../include/readcfg.php');
    include('../lib/formatbytesbites.php'); // For formatting data limits

    // Get parameters from URL
    $id = $_GET['id'];         // Batch comment/identifier
    $qr = $_GET['qr'];         // QR code parameter (kept for potential future use)
    $small = $_GET['small'];   // Size parameter for printing (affects preview grid, not new print template width)
    $userp = $_GET['user'];    // Specific single username

    // Include RouterOS API class
    require('../lib/routeros_api.class.php');
    $API = new RouterosAPI();
    $API->debug = false; // Set to true for API debugging

    // Connect to the MikroTik router
    if (!$API->connect($iphost, $userhost, decrypt($passwdhost))) {
        // Handle connection error gracefully
        echo "<!DOCTYPE html><html><head><title>Error</title></head><body>";
        echo "<h1>Connection Error</h1><p>Could not connect to the MikroTik router ($iphost). Please check the connection details and ensure the router is reachable.</p>";
        // Optionally log the error
        // error_log("Failed to connect to MikroTik router: $iphost");
        echo "</body></html>";
        exit;
    }


    $getuser = []; // Initialize array for user data
    $TotalReg = 0; // Initialize count of fetched users
    $getuprofile = 'default'; // Default profile name

    // Fetch user data based on parameters
    if ($userp != "") {
        // Fetch a single user by username
        $getuser = $API->comm("/ip/hotspot/user/print", ["?name" => $userp]);
        $TotalReg = count($getuser);
    } elseif ($id != "") {
        // Fetch users by comment (batch ID), ensuring they haven't been used (uptime is 0s)
        // Note: This uptime check might not be reliable if users log in very briefly.
        // Consider alternative methods like disabling users after printing if needed.
        // Fetch all users by comment, regardless of uptime for now, as required by the logic flow
        $getuser = $API->comm('/ip/hotspot/user/print', ["?comment" => "$id"]);
        $TotalReg = count($getuser);
        // If you strictly want only unused (0s uptime):
        // $getuser = $API->comm('/ip/hotspot/user/print', ["?comment" => "$id", "?uptime" => "0s"]);
        // $TotalReg = count($getuser);
    }

    // Disconnect from API after fetching data
    $API->disconnect();

    // Array to hold ticket data for JavaScript processing (Firebase)
    $tickets_for_js = [];
    // Price variables initialization
    $batch_price_value = 0.0; // Use float for calculations
    $price = ""; // Formatted price string for display
    $default_profile_name_for_js = "default"; // Default profile name for JS fallback

    // Store details of the first user for print template approximation
    $firstUser = null;
    if ($TotalReg > 0) {
        $firstUser = $getuser[0]; // Store first user data
        // Get profile name from the first user (assuming all in batch have the same profile)
        $getuprofile = isset($firstUser['profile']) ? $firstUser['profile'] : 'default';
        $default_profile_name_for_js = $getuprofile; // Assign actual profile name

        // Re-connect to get profile details (could potentially fetch this earlier)
        // Consider fetching profile details ONLY if price logic is needed and $getuprofile is valid
        $API = new RouterosAPI(); // Need a new instance or ensure the previous one is reusable
        if ($API->connect($iphost, $userhost, decrypt($passwdhost))) {
            $getprofile = $API->comm("/ip/hotspot/user/profile/print", ["?name" => "$getuprofile"]);
            $API->disconnect();

            // Extract price information from the profile's 'on-login' script if available
            if (isset($getprofile[0], $getprofile[0]['on-login'])) {
                $ponlogin = $getprofile[0]['on-login'];
                $ponlogin_parts = explode(",", $ponlogin); // Split script by comma
                // Extract cost price (index 2) and selling price (index 4)
                $getprice_from_profile = isset($ponlogin_parts[2]) ? trim($ponlogin_parts[2]) : "0";
                $getsprice_from_profile = isset($ponlogin_parts[4]) ? trim($ponlogin_parts[4]) : "0";

                // Determine the batch price: prioritize selling price, then cost price
                if ($getsprice_from_profile != "0") {
                    $batch_price_value = (float)$getsprice_from_profile;
                } elseif ($getprice_from_profile != "0") {
                    $batch_price_value = (float)$getprice_from_profile;
                } else {
                    $batch_price_value = 0.0; // Default to 0 if neither is set
                }

                // Format the price string for display based on currency settings
                if ($batch_price_value > 0) {
                     // Check if currency is Indonesian Rupiah for specific formatting
                     if (isset($cekindo['indo']) && is_array($cekindo['indo']) && in_array($currency, $cekindo['indo'])) {
                         $price = $currency . " " . number_format($batch_price_value, 0, ",", "."); // Format for IDR (no decimals)
                     } else {
                         $price = $currency . " " . number_format($batch_price_value, 2); // Standard format (2 decimals)
                     }
                } else {
                     $price = ""; // No price to display
                }

            } else {
                // Handle case where profile or 'on-login' script is not found
                $price = ""; // No price information available
                $batch_price_value = 0.0;
                 // Log this event if necessary: error_log("Profile '$getuprofile' or on-login script not found for session '$session'.");
            }
        } else {
             // Handle API connection error for profile fetching
             $price = "";
             $batch_price_value = 0.0;
             // error_log("Failed to connect to MikroTik router for profile fetching: $iphost");
        }


        // Populate the array for JavaScript with data from all fetched users
        for ($i = 0; $i < $TotalReg; $i++) {
            if (isset($getuser[$i])) { // Ensure user data exists at this index
                $regtable = $getuser[$i];
                $username = isset($regtable['name']) ? $regtable['name'] : 'N/A';
                $password = isset($regtable['password']) ? $regtable['password'] : 'N/A';
                $profile = isset($regtable['profile']) ? $regtable['profile'] : $getuprofile; // Use batch profile if individual is missing
                $comment = isset($regtable['comment']) ? $regtable['comment'] : ''; // Batch ID or other comment
                // Fetch limits for this specific user (more accurate for JS data, but might slow down if many users)
                // Optional: stick to first user's limits for performance if needed
                $user_timelimit = isset($regtable['limit-uptime']) ? $regtable['limit-uptime'] : (isset($firstUser['limit-uptime']) ? $firstUser['limit-uptime'] : '');
                $user_getdatalimit = isset($regtable['limit-bytes-total']) ? $regtable['limit-bytes-total'] : (isset($firstUser['limit-bytes-total']) ? $firstUser['limit-bytes-total'] : 0);
                $user_datalimit_formatted = "";
                if ($user_getdatalimit != 0 && $user_getdatalimit != "") { $user_datalimit_formatted = formatBytes($user_getdatalimit, 2); }


                $tickets_for_js[] = [
                    'username' => $username,
                    'password' => $password,
                    'profile' => $profile, // This is the category source for TicketsTotal default
                    'price' => (string)$batch_price_value, // Pass batch price as string
                    'comment' => $comment,
                    'timelimit' => $user_timelimit, // Store specific time limit
                    'datalimit' => $user_datalimit_formatted // Store specific data limit (formatted)
                ];
            }
        }
    } else {
         // No users found, set profile name to default for display consistency
         $getuprofile = 'N/A'; // Or leave as 'default'
    }


    // Determine logo path (Not used in new print template, kept for potential future use)
    // $logo_path = "../img/logo-" . $session . ".png";
    // if (!file_exists($logo_path)) {
    //     $logo_path = "../img/logo.png"; // Default logo
    // }
    // Append timestamp to prevent caching issues
    // $logo_url = $logo_path . "?t=" . time();

} // End of initial session check else block
?>

<!DOCTYPE html>
<html>
<head>
    <title>Voucher-<?= htmlspecialchars($hotspotname) . "-" . htmlspecialchars($getuprofile) . ($id ? "-" . htmlspecialchars($id) : ""); ?></title>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <meta http-equiv="pragma" content="no-cache" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0"> <!-- Responsive viewport -->
    <link rel="icon" href="../img/favicon.png" />
    <!-- <script src="../js/qrious.min.js"></script> --> <!-- QR Script commented out -->
    <style>
        /* --- Base Styles --- */
        body { color: #333; background-color: #f4f4f4; font-size: 14px; font-family: 'Helvetica', arial, sans-serif; margin: 0; padding: 0; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
        strong { font-weight: bold; }

        /* --- Modal Styles --- */
        .modal { display: none; /* Hidden by default */ position: fixed; z-index: 1000; left: 0; top: 0; width: 100%; height: 100%; overflow: auto; background-color: rgba(0,0,0,0.6); }
        .modal-content { background-color: #fefefe; margin: 3% auto; padding: 25px; border: 1px solid #bbb; width: 90%; max-width: 1100px; max-height: 90vh; overflow-y: auto; position: relative; border-radius: 8px; box-shadow: 0 5px 15px rgba(0,0,0,0.3); }
        .close-button { color: #aaa; position: absolute; top: 10px; right: 20px; font-size: 30px; font-weight: bold; line-height: 1; cursor: pointer; transition: color 0.3s ease; }
        .close-button:hover, .close-button:focus { color: #333; text-decoration: none; }
        .modal h2 { margin-top: 0; color: #0056b3; border-bottom: 1px solid #eee; padding-bottom: 10px; margin-bottom: 20px; font-size: 1.5em; }

        /* --- Ticket List Styles (in Preview Modal) --- */
        .ticket-list { display: grid; grid-template-columns: repeat(auto-fill, minmax(<?= ($small == "yes" ? '180px' : '240px') ?>, 1fr)); gap: 15px; margin-top: 15px; margin-bottom: 20px; padding: 5px; }
        .ticket-item { border: 1px solid #ccc; padding: 12px; background-color: #fff; font-size: 12px; line-height: 1.4; overflow: hidden; display: flex; flex-direction: column; justify-content: space-between; border-radius: 4px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); }
        .ticket-item div { margin-bottom: 4px; word-wrap: break-word; } /* Allow long usernames/passwords to wrap */
        .ticket-item .hotspot-name { text-align:center; font-weight: bold; margin-bottom: 6px; font-size: 1.1em; color: #333; }

        /* --- Action Buttons Styles --- */
        .action-buttons { margin-top: 25px; padding-top: 20px; border-top: 1px solid #eee; text-align: center; }
        .action-buttons button { padding: 10px 22px; margin: 5px 10px; cursor: pointer; border: none; border-radius: 5px; font-size: 14px; font-weight: bold; transition: background-color 0.3s ease, box-shadow 0.3s ease; }
        .action-buttons button.save-total { background-color: #28a745; color: white; }
        .action-buttons button.save-total:hover { background-color: #218838; box-shadow: 0 2px 5px rgba(0,0,0,0.2); }
        .action-buttons button.print { background-color: #007bff; color: white; }
        .action-buttons button.print:hover { background-color: #0056b3; box-shadow: 0 2px 5px rgba(0,0,0,0.2); }
        .action-buttons button.confirm { background-color: #007bff; color: white; }
        .action-buttons button.confirm:hover { background-color: #0056b3; }
        .action-buttons button.cancel { background-color: #6c757d; color: white; }
        .action-buttons button.cancel:hover { background-color: #5a6268; }
        .action-buttons button:disabled { background-color: #cccccc; cursor: not-allowed; box-shadow: none; opacity: 0.7; }

        /* --- Loading Overlay (Now only used for user-initiated saves) --- */
        #loadingOverlay { position: fixed; top: 0; left: 0; width: 100%; height: 100%; background-color: rgba(0, 0, 0, 0.75); display: none; /* Initially hidden */ justify-content: center; align-items: center; z-index: 1001; color: white; font-size: 1.3em; text-shadow: 1px 1px 2px black; }
        #loadingOverlay::after { content: ""; width: 40px; height: 40px; border: 5px solid #f3f3f3; border-top: 5px solid #3498db; border-radius: 50%; animation: spin 1s linear infinite; margin-left: 15px; }
        @keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }

        /* --- Print Area Styles (Container for the new template) --- */
        #printArea { display: none; /* Hidden until print button is clicked */ margin: 0; padding: 0; font-size: 10pt; background-color: #fff; /* Ensure white background for printing */ text-align: left; /* Or center if needed */ }
        /* Style for each voucher TABLE within the print area */
        #printArea .voucher {
            display: inline-block; /* Arrange tables side-by-side */
            vertical-align: top;
            width: 160px; /* Width from the template */
            margin: 2mm; /* Spacing between vouchers */
            page-break-inside: avoid; /* Try to keep each voucher on one page */
            border-collapse: collapse; /* Clean up table borders */
            box-sizing: border-box;
            overflow: hidden;
            border: 1px solid #eee; /* Optional faint border for visual separation before print */
        }
         /* Explicit styles for the template's elements for better print control */
         #printArea .voucher td {
             padding: 1px 3px; /* Adjust padding as needed */
             vertical-align: middle;
             word-wrap: break-word; /* Ensure long text wraps */
         }
         #printArea .voucher .header-cell { /* Target the specific cell for hotspot name */
            text-align: left;
            font-size: 14px;
            font-weight: bold;
            border-bottom: 1px black solid;
         }
         #printArea .voucher .details-table { /* Inner table */
            text-align: center;
            width: 150px; /* Inner table width */
            margin: 2px auto; /* Center inner table */
         }
         #printArea .voucher .details-table td {
             font-size: 11px;
             border: 1px solid black;
             padding: 2px;
         }
          #printArea .voucher .details-table .label-row td { /* Row with "Username", "Password" */
             border: none; /* Remove border from label row */
             font-size: 10px;
             text-align: center;
             padding-bottom: 0;
         }
         #printArea .voucher .details-table .value-row td { /* Row with actual user/pass/code */
             font-size: 14px;
             font-weight: bold;
         }
         #printArea .voucher .details-table .info-row td { /* Bottom row with limits/price */
             font-size: 10px; /* Slightly smaller */
             font-weight: bold;
         }


        /* --- Category Modal Specific Styles --- */
        #categoryModal .modal-content { max-width: 500px; }
        #categoryModal label { display: block; margin-bottom: 5px; font-weight: bold; color: #555; }
        #categoryModal input[type="text"],
        #categoryModal select { width: 100%; padding: 10px; margin-bottom: 15px; border: 1px solid #ccc; border-radius: 4px; box-sizing: border-box; font-size: 1em; }
        #categoryModal input[type="text"]:focus,
        #categoryModal select:focus { border-color: #007bff; outline: none; box-shadow: 0 0 0 2px rgba(0, 123, 255, 0.25); }
        #defaultCategoryDisplay { background-color: #e9ecef; padding: 8px; border-radius: 4px; margin-bottom: 15px; font-style: italic; color: #495057; }

            /* --- Print Styles --- */
        @page { size: auto; margin: 5mm 5mm 5mm 5mm; /* Adjust margins */ }
        @media print {
            body { background-color: #FFFFFF !important; color: #000000 !important; margin: 0; padding: 0; }
            #ticketsModal, #categoryModal, .action-buttons:not(.print-actions), .close-button, #loadingOverlay { display: none !important; } /* Hide modals and non-print buttons */
            #printArea { display: block !important; margin: 0; padding: 0; background-color: white !important; text-align: left; /* Reset alignment for print */ }
            #printArea .voucher {
                /* border: none;  <-- REMOVE OR COMMENT OUT THIS LINE */
                border: 1px solid black !important; /* <-- ADD THIS LINE */
                margin: 2mm !important; /* Keep spacing, use !important if needed */
                display: inline-block !important; /* Ensure they stay inline */
                background-color: white !important; /* Force white background */
                -webkit-print-color-adjust: exact; /* Ensure colors/borders print */
                print-color-adjust: exact;
                box-sizing: border-box; /* Ensure border is included in width */
                overflow: hidden; /* Prevent content spill */
            }
            /* Ensure nested table borders print correctly */
            #printArea .voucher td, #printArea .voucher th { border-color: black !important; }
             /* Ensure specific borders from template print */
            #printArea .voucher .header-cell { border-bottom: 1px black solid !important; }
            #printArea .voucher .details-table td { border: 1px solid black !important; }
            #printArea .voucher .details-table .label-row td { border: none !important; } /* Keep label row borderless */
        }
    </style>
</head>
<body>

<!-- Loading Overlay (Only for user-initiated saves now) -->
<div id="loadingOverlay">Processing...</div>

<!-- Main Voucher Preview Modal -->
<div id="ticketsModal" class="modal" style="display: block;"> <!-- Show this modal initially -->
    <div class="modal-content">
        <span class="close-button" id="closeModalBtn">×</span>
        <h2>Voucher Preview - <?= htmlspecialchars($hotspotname) . " / " . htmlspecialchars($getuprofile) . ($id ? " / " . htmlspecialchars($id) : ""); ?> (<?= $TotalReg ?> Tickets)</h2>
        <div class="ticket-list" id="ticketListContainer">
            <?php if ($TotalReg > 0): ?>
                <?php foreach ($tickets_for_js as $ticket): // Use the JS array which is already populated ?>
                    <!-- Display voucher in the PREVIEW modal (Original simpler format) -->
                    <div class="ticket-item">
                        <div>
                           <div class="hotspot-name"><?= htmlspecialchars($hotspotname) ?></div>
                        </div>
                        <div>
                            <div><strong>Username:</strong> <?= htmlspecialchars($ticket['username']) ?></div>
                            <div><strong>Password:</strong> <?= htmlspecialchars($ticket['password']) ?></div>
                            <?php if($price != ""): // Use batch price for preview consistency ?>
                            <div><strong>Price:</strong> <?= htmlspecialchars($price) ?></div>
                            <?php endif; ?>
                            <?php // Use the specific limits stored in the JS array for preview ?>
                            <?php if(isset($ticket['timelimit']) && $ticket['timelimit'] != "" && $ticket['timelimit'] != "0s"): ?>
                            <div><strong>Time:</strong> <?= htmlspecialchars($ticket['timelimit']) ?></div>
                            <?php endif; ?>
                            <?php if(isset($ticket['datalimit']) && $ticket['datalimit'] != ""): ?>
                            <div><strong>Data:</strong> <?= htmlspecialchars($ticket['datalimit']) ?></div>
                            <?php endif; ?>
                            <div><strong>Profile:</strong> <?= htmlspecialchars($ticket['profile']) ?></div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <p style="text-align: center; padding: 20px; color: #555;">No vouchers found matching the criteria.</p>
            <?php endif; ?>
        </div>

<!-- Dans la div.action-buttons de #ticketsModal -->
<div class="action-buttons">
    <button id="saveTotalBtn" class="save-total" <?= ($TotalReg == 0 ? 'disabled' : '') ?>>Enregistrer pour vente en ligne</button>
    <!-- NOUVEAU BOUTON AJOUTÉ ICI -->
    <button id="stockPartnerBtn" style="background-color: #ffc107; color: black;" <?= ($TotalReg == 0 ? 'disabled' : '') ?>>Approvisionner un partenaire</button>
    <button id="printBtn" class="print" <?= ($TotalReg == 0 ? 'disabled' : '') ?>>Imprimer</button>
</div>
    </div>
</div>

<!-- Category Selection Modal (for TicketsTotal) -->
<div id="categoryModal" class="modal">
    <div class="modal-content">
         <span class="close-button" onclick="document.getElementById('categoryModal').style.display='none';">×</span>
        <h2>Choisir la catégorie pour TicketsTotal</h2>
        <p>Sélectionnez une catégorie existante ou entrez un nouveau nom.</p>

        <div>
            <label>Catégorie par défaut (Profil):</label>
            <div id="defaultCategoryDisplay">Loading...</div>
        </div>

        <div>
            <label for="categorySelect">Choisir une catégorie existante :</label>
            <select id="categorySelect">
                <option value="">-- Aucune (Utiliser l'entrée ci-dessous ou le défaut) --</option>
                <!-- Options will be populated by JavaScript -->
            </select>
        </div>

         <div>
            <label for="categoryInput">Ou entrer un nouveau nom de catégorie :</label>
            <input type="text" id="categoryInput" placeholder="Entrer un nouveau nom ici">
        </div>

        <div class="action-buttons">
            <button id="confirmCategoryBtn" class="confirm">Confirmer la catégorie</button>
            <button id="cancelCategoryBtn" class="cancel" onclick="document.getElementById('categoryModal').style.display='none';">Annuler</button>
        </div>
    </div>
</div>

<!-- NOUVELLE MODALE POUR LE STOCK PARTENAIRE -->
<div id="partnerStockModal" class="modal">
    <div class="modal-content">
        <span class="close-button" onclick="document.getElementById('partnerStockModal').style.display='none';">×</span>
        <h2>Approvisionner un Partenaire</h2>
        <p>Vous êtes sur le point d'envoyer <strong id="partnerStockQuantity" style="font-size: 1.2em;"><?= $TotalReg ?></strong> tickets comme un nouvel approvisionnement.</p>

        <div>
            <label for="partnerSelect">Choisir un partenaire/vendeur :</label>
            <select id="partnerSelect">
                <option value="">-- Veuillez sélectionner un partenaire --</option>
                <!-- Options des partenaires chargées par JavaScript -->
            </select>
        </div>

        <div>
            <label for="partnerCategorySelect">Confirmer la catégorie de produit :</label>
            <select id="partnerCategorySelect">
                <option value="">-- Veuillez sélectionner une catégorie --</option>
                <!-- Options des catégories chargées par JavaScript -->
            </select>
        </div>

        <div class="action-buttons">
            <button id="confirmPartnerStockBtn" class="confirm">Confirmer l'Approvisionnement</button>
            <button class="cancel" onclick="document.getElementById('partnerStockModal').style.display='none';">Annuler</button>
        </div>
    </div>
</div>


<!-- Vouchers formatted for Printing (Hidden by default, using NEW TEMPLATE) -->
<div id="printArea">
    <?php if ($TotalReg > 0): ?>
        <?php
            // Get shared details (approximated from first user) for the print template footer row
            $print_timelimit = isset($firstUser['limit-uptime']) && $firstUser['limit-uptime'] !== '0s' ? $firstUser['limit-uptime'] : '';
            $print_getdatalimit = isset($firstUser['limit-bytes-total']) ? $firstUser['limit-bytes-total'] : 0;
            $print_datalimit = "";
            if ($print_getdatalimit != 0 && $print_getdatalimit != "") { $print_datalimit = formatBytes($print_getdatalimit, 2); }
            $print_price = $price; // Use the already calculated batch price string
            $print_validity = ''; // Validity is not fetched, leave blank or fetch if needed
        ?>
        <?php foreach ($tickets_for_js as $ticket): ?>
            <?php
                // Determine user mode for template (vc = username is code, up = user/pass separate)
                $usermode = ($ticket['username'] === $ticket['password']) ? "vc" : "up";
                $username = htmlspecialchars($ticket['username']);
                $password = htmlspecialchars($ticket['password']);
            ?>
            <table class="voucher">
              <tbody>
                <tr>
                  <td class="header-cell"><?= htmlspecialchars($hotspotname) ?></td>
                </tr>
                <tr>
                  <td>
                    <table class="details-table">
                      <tbody>
                        <!-- Username = Password -->
                        <?php if ($usermode == "vc"): ?>
                            <tr class="label-row">
                              <td>Kode Voucher</td>
                            </tr>
                            <tr class="value-row">
                              <td style="width:100%;"><?= $username ?></td>
                            </tr>
                            <tr class="info-row">
                              <td colspan="2"><?= htmlspecialchars($print_validity) ?> <?= htmlspecialchars($print_timelimit) ?> <?= htmlspecialchars($print_datalimit) ?> <?= htmlspecialchars($print_price) ?></td>
                            </tr>
                        <!-- Username & Password -->
                        <?php elseif ($usermode == "up"): ?>
                            <tr class="label-row">
                              <td style="width: 50%">Username</td>
                              <td>Password</td>
                            </tr>
                            <tr class="value-row">
                              <td><?= $username ?></td>
                              <td><?= $password ?></td>
                            </tr>
                            <tr class="info-row">
                              <td colspan="2"><?= htmlspecialchars($print_validity) ?> <?= htmlspecialchars($print_timelimit) ?> <?= htmlspecialchars($print_datalimit) ?> <?= htmlspecialchars($print_price) ?></td>
                            </tr>
                        <?php endif; ?>
                      </tbody>
                    </table>
                  </td>
                </tr>
              </tbody>
            </table>
        <?php endforeach; ?>
    <?php endif; ?>
</div>


<!-- Firebase and Interaction Logic -->
<script type="module">
    // --- Import Firebase Modules ---
    import { getActiveDatabase } from './firebase-config-manager.js';
    import { getDatabase, ref, get, update, push, serverTimestamp, query, orderByChild, equalTo } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-database.js";

    // --- Configuration & Data from PHP ---
    const allGeneratedTickets = <?= json_encode($tickets_for_js); ?>;
    const totalTicketsGenerated = <?= $TotalReg ?>;
    const defaultProfileName = <?= json_encode($default_profile_name_for_js); ?>; // Get profile name from PHP

    // --- DOM Elements ---
    const ticketsModal = document.getElementById('ticketsModal');
    const categoryModal = document.getElementById('categoryModal');
    const closeModalBtn = document.getElementById('closeModalBtn');
    const saveTotalBtn = document.getElementById('saveTotalBtn');
    const printBtn = document.getElementById('printBtn');
    const loadingOverlay = document.getElementById('loadingOverlay');
    const printArea = document.getElementById('printArea');
    const ticketListContainer = document.getElementById('ticketListContainer');
    const defaultCategoryDisplay = document.getElementById('defaultCategoryDisplay');
    const categorySelect = document.getElementById('categorySelect');
    const categoryInput = document.getElementById('categoryInput');
    const confirmCategoryBtn = document.getElementById('confirmCategoryBtn');
    const cancelCategoryBtn = document.getElementById('cancelCategoryBtn');
    const stockPartnerBtn = document.getElementById('stockPartnerBtn');
    const partnerStockModal = document.getElementById('partnerStockModal');
    const partnerSelect = document.getElementById('partnerSelect');
    const partnerCategorySelect = document.getElementById('partnerCategorySelect');
    const partnerStockQuantity = document.getElementById('partnerStockQuantity');
    const confirmPartnerStockBtn = document.getElementById('confirmPartnerStockBtn');

    // --- State ---
    let existingCategories = [];
    let firebaseDb = null; // Hold the DB instance
    let currentUserId = localStorage.getItem('firebaseUserId'); // Retrieve stored Firebase User ID

    // --- Helper Functions ---
    function showLoading(message = "Processing...") {
        loadingOverlay.textContent = message;
        loadingOverlay.style.display = 'flex';
        disableButtons(true);
        confirmCategoryBtn.disabled = true; // Also disable category confirm button
    }
    function hideLoading() {
        loadingOverlay.style.display = 'none';
        // Enable buttons only if tickets were generated
        disableButtons(totalTicketsGenerated === 0);
        confirmCategoryBtn.disabled = false;
    }
    function disableButtons(disabled) {
        saveTotalBtn.disabled = disabled;
        printBtn.disabled = disabled;
        // Keep confirm category button enabled unless explicitly disabled during loading
    }
    function showNotification(type, message) {
        // Simple alert, replace with a nicer notification system if available
        console.log(`[${type.toUpperCase()}] ${message}`); // Log to console for less intrusion
        // alert(`[${type.toUpperCase()}] ${message}`); // Keep alert for critical errors if needed
        if (type === 'error') {
            alert(`[ERREUR] ${message}`); // Use alert for errors
        }
    }

        /**
     * NOUVEAU : Convertit un objet Date en une chaîne de caractères locale
     * au format YYYY-MM-DDTHH:mm, sans conversion UTC.
     * @param {Date} date - L'objet Date à formater.
     * @returns {string} La date formatée pour un input datetime-local.
     */
    function toLocalISOString(date) {
        const pad = num => num.toString().padStart(2, '0');

        const year = date.getFullYear();
        const month = pad(date.getMonth() + 1); // +1 car les mois sont de 0 à 11
        const day = pad(date.getDate());
        const hours = pad(date.getHours());
        const minutes = pad(date.getMinutes());

        return `${year}-${month}-${day}T${hours}:${minutes}`;
    }

    /**
     * Initialize Firebase Database instance.
     */
    async function initializeDb() {
        if (!firebaseDb) {
            try {
                firebaseDb = await getActiveDatabase();
                if (!firebaseDb) throw new Error("Failed to get active Firebase database instance.");
                 console.log("Firebase DB Initialized for print page.");
            } catch (error) {
                console.error("Firebase DB Initialization Error:", error);
                showNotification('error', `Firebase Initialization Failed: ${error.message}`);
                disableButtons(true); // Disable actions if DB fails
                 confirmCategoryBtn.disabled = true;
            }
        }
        return firebaseDb;
    }


    /**
     * NOUVEAU : Récupère la liste des partenaires/vendeurs depuis Firebase.
     * Ces partenaires sont gérés depuis la page Stock.html.
     */
    async function fetchPartners() {
        if (!currentUserId || currentUserId === 'XXXXXXXXXXX') {
             showNotification('error', 'Firebase User ID non configuré.');
             return [];
        }
        const db = await initializeDb();
        if (!db) return [];

        const vendorsRef = ref(db, `users-data/${currentUserId}/Vendors`);
        try {
            const snapshot = await get(vendorsRef);
            const partners = [];
            if (snapshot.exists()) {
                const vendors = snapshot.val();
                for (const vendorName in vendors) {
                    partners.push({ id: vendorName, name: vendorName });
                }
            }
            // Ajouter l'administrateur lui-même comme une option de vendeur possible
            partners.push({ id: currentUserId, name: `Admin (${currentUserId.substring(0, 6)}...)` });
            return partners.sort((a, b) => a.name.localeCompare(b.name));
        } catch (error) {
            console.error("Error fetching partners:", error);
            showNotification('error', `Failed to fetch partners: ${error.message}`);
            return [];
        }
    }

    /**
     * NOUVEAU : Remplit la liste déroulante des partenaires dans la nouvelle modale.
     * @param {Array} partners - Un tableau d'objets partenaire.
     */
    function populatePartnerSelect(partners) {
        partnerSelect.innerHTML = '<option value="">-- Veuillez sélectionner un partenaire --</option>';
        if (partners && partners.length > 0) {
            partners.forEach(partner => {
                const option = document.createElement('option');
                option.value = partner.id;
                option.textContent = partner.name;
                partnerSelect.appendChild(option);
            });
        }
    }

    /**
     * NOUVEAU : Remplit la liste déroulante des catégories dans la nouvelle modale.
     * Réutilise la variable globale `existingCategories`.
     */
    function populatePartnerCategorySelect() {
        partnerCategorySelect.innerHTML = '<option value="">-- Veuillez sélectionner une catégorie --</option>';
        existingCategories.forEach(cat => {
            const option = document.createElement('option');
            option.value = cat;
            option.textContent = cat;
            partnerCategorySelect.appendChild(option);
        });
        // Tenter de présélectionner la catégorie par défaut
        if (existingCategories.includes(defaultProfileName)) {
            partnerCategorySelect.value = defaultProfileName;
        }
    }


    /**
     * NOUVELLE VERSION : Gère la logique de sauvegarde de l'approvisionnement pour un partenaire.
     * Cette version lit d'abord le dernier stock final pour le produit concerné.
     */
    async function handlePartnerStockSave() {
        const selectedPartnerId = partnerSelect.value;
        const selectedCategory = partnerCategorySelect.value;

        if (!selectedPartnerId || !selectedCategory) {
            showNotification('error', 'Veuillez sélectionner un partenaire ET une catégorie.');
            return;
        }
        
        // Message mis à jour pour indiquer la vérification
        showLoading("Vérification du stock existant...");

        try {
            const db = await initializeDb();
            let lastStockFinal = 0; // Le Stock Initial par défaut est 0

            // --- DEBUT DE LA NOUVELLE LOGIQUE DE LECTURE ---
            // 1. Récupérer l'historique des opérations pour le partenaire sélectionné
            const stockHistoryRef = ref(db, `users-data/${currentUserId}/StockOperations/${selectedPartnerId}`);
            const snapshot = await get(stockHistoryRef);

            if (snapshot.exists()) {
                const allOperations = snapshot.val();
                let latestOperationForProduct = null;
                let latestDateTime = new Date(0); // Initialiser avec une date très ancienne

                // 2. Itérer sur toutes les opérations pour trouver la plus récente pour le produit choisi
                for (const key in allOperations) {
                    const operation = allOperations[key];
                    
                    // S'assurer que l'opération concerne bien le produit sélectionné
                    if (operation.product === selectedCategory) {
                        const operationDate = new Date(operation.dateTime);
                        // Si cette opération est plus récente que la dernière trouvée, on la garde
                        if (operationDate > latestDateTime) {
                            latestDateTime = operationDate;
                            latestOperationForProduct = operation;
                        }
                    }
                }

                // 3. Si une opération a été trouvée, utiliser son Stock Final
                if (latestOperationForProduct) {
                    lastStockFinal = parseInt(latestOperationForProduct.SF, 10) || 0;
                    console.log(`Dernier Stock Final trouvé pour '${selectedCategory}': ${lastStockFinal}`);
                }
            }
            // --- FIN DE LA NOUVELLE LOGIQUE DE LECTURE ---

            showLoading("Enregistrement de l'approvisionnement...");

            // 4. Construire l'objet de données avec les valeurs correctes
            const stockInitial = lastStockFinal;
            const newApprovisionnement = totalTicketsGenerated;
            const stockFinal = stockInitial + newApprovisionnement; // SF = SI + APP

            const operationData = {
dateTime: toLocalISOString(new Date()),
                product: selectedCategory,
                SI: stockInitial,          // <-- Valeur corrigée
                APP: newApprovisionnement,
                V: 0,
                SF: stockFinal,            // <-- Valeur corrigée
                PV: parseFloat(<?= json_encode($batch_price_value); ?>) || 0,
                vendor: selectedPartnerId,
                accountingMode: 'shared'
            };

            // 5. Envoyer les données à Firebase
            const stockOperationsRef = ref(db, `users-data/${currentUserId}/StockOperations/${selectedPartnerId}`);
            await push(stockOperationsRef, operationData);

            showNotification('success', `Approvisionnement de ${newApprovisionnement} tickets pour '${selectedPartnerId}' enregistré ! Nouveau stock : ${stockFinal}`);
            partnerStockModal.style.display = 'none';

        } catch (error) {
            console.error("Error saving partner stock operation:", error);
            showNotification('error', `Erreur enregistrement : ${error.message}`);
        } finally {
            hideLoading();
        }
    }

    // NOUVEAU : Écouteur pour le bouton "Stock partenaire"
    stockPartnerBtn.addEventListener('click', async () => {
        showLoading("Chargement des données...");
        try {
            const [partners] = await Promise.all([
                fetchPartners(),
                fetchExistingCategories() // Assure que les catégories sont à jour
            ]);
            
            populatePartnerSelect(partners);
            populatePartnerCategorySelect();
            
            partnerStockQuantity.textContent = totalTicketsGenerated;
            partnerStockModal.style.display = 'block';
        } catch (e) {
            showNotification('error', 'Erreur lors de la préparation de la fenêtre de stock.');
            console.error(e);
        } finally {
            hideLoading();
        }
    });

    // NOUVEAU : Écouteur pour le bouton de confirmation dans la modale de stock
    confirmPartnerStockBtn.addEventListener('click', handlePartnerStockSave);


    /**
     * Fetches existing category names from the user's TicketsTotal node.
     */
    async function fetchExistingCategories() {
        if (!currentUserId || currentUserId === 'XXXXXXXXXXX') {
             showNotification('error', 'Firebase User ID non configuré.');
             return [];
        }
        const db = await initializeDb();
        if (!db) return [];

        const categoriesRef = ref(db, `users-data/${currentUserId}/TicketsTotal`);
        try {
            const snapshot = await get(categoriesRef);
            if (snapshot.exists()) {
                existingCategories = Object.keys(snapshot.val()).sort(); // Get and sort category names
                return existingCategories;
            } else {
                return []; // No categories exist yet
            }
        } catch (error) {
            console.error("Error fetching existing categories:", error);
            showNotification('error', `Failed to fetch categories: ${error.message}`);
            return [];
        }
    }

    /**
     * Populates the category selection dropdown.
     */
    function populateCategorySelect() {
        categorySelect.innerHTML = '<option value="">-- Aucune (Utiliser l\'entrée ou le défaut) --</option>'; // Reset
        existingCategories.forEach(cat => {
            const option = document.createElement('option');
            option.value = cat;
            option.textContent = cat;
            categorySelect.appendChild(option);
        });
    }


    /**
     * Processes and saves tickets, handling TicketsTotal or TicketsTransit/Archive.
     * @param {string} primaryTarget - 'TicketsTotal' or 'TicketsTransit'.
     * @param {string|null} targetCategoryName - The specific category for TicketsTotal.
     * @param {boolean} silent - If true, suppress loading overlay and use console for notifications.
     */
    async function processAndSaveTickets(primaryTarget, targetCategoryName = null, silent = false) {
         if (!currentUserId || currentUserId === 'XXXXXXXXXXX') {
            showNotification('error', 'Firebase User ID is not configured correctly.');
            if (!silent) hideLoading();
            return false;
        }
        if (!allGeneratedTickets || allGeneratedTickets.length === 0) {
            if (!silent) showNotification('info', 'No ticket data found to process.');
            if (!silent) hideLoading();
            return true; // Nothing to do, not an error
        }

        const db = await initializeDb();
        if (!db) {
            if (!silent) hideLoading();
             return false;
        }

        if (!silent) {
            showLoading(`Chargement tickets dans ${primaryTarget}...`);
        } else {
            console.log(`Starting background processing for ${primaryTarget}...`);
            // Optionally show a very subtle indicator, e.g., on the save button
            // saveTotalBtn.textContent = 'Syncing...'; // Example
        }

        try {
            const updates = {}; // Combined updates for batch write
            let addedToTransitCount = 0;
            let addedToArchiveCount = 0;
            let skippedCount = 0; // Count skipped duplicates for Transit/Archive
            let addedToTotalCount = 0; // Count added/merged for Total

            // --- Logic for TicketsTotal (Requires targetCategoryName) ---
            if (primaryTarget === 'TicketsTotal') {
                if (!targetCategoryName) {
                    throw new Error("Target category name is required for saving to TicketsTotal.");
                }
                const dbPathPrefix = `users-data/${currentUserId}/TicketsTotal`;
                const categoryRef = ref(db, `${dbPathPrefix}/${targetCategoryName}`);

                // Fetch existing data for the target category to merge
                const snapshot = await get(categoryRef);
                const existingData = snapshot.val() || { motDePasse: [], prix: [], utilisateur: [] };
                // Ensure arrays exist even if category is new
                existingData.motDePasse = existingData.motDePasse || [];
                existingData.prix = existingData.prix || [];
                existingData.utilisateur = existingData.utilisateur || [];

                // Prepare new data from the generated tickets
                const newPasswords = allGeneratedTickets.map(t => t.password);
                const newPrices = allGeneratedTickets.map(t => t.price);
                const newUsers = allGeneratedTickets.map(t => t.username);

                // Merge existing and new data
                const mergedData = {
                    motDePasse: [...existingData.motDePasse, ...newPasswords],
                    prix: [...existingData.prix, ...newPrices],
                    utilisateur: [...existingData.utilisateur, ...newUsers]
                };

                // Add the update operation to the batch
                updates[`${dbPathPrefix}/${targetCategoryName}`] = mergedData;
                addedToTotalCount = newUsers.length; // Count how many were prepared for this category

                const msg = `${addedToTotalCount} ticket(s) prepared for saving to TicketsTotal category: '${targetCategoryName}'.`;
                if (silent) console.log(msg); else showNotification('info', msg);

            // --- Logic for TicketsTransit & TicketsArchive ---
            } else if (primaryTarget === 'TicketsTransit') {
                const transitPath = `users-data/${currentUserId}/TicketsTransit`;
                const archivePath = `users-data/${currentUserId}/TicketsArchive`;

                // 1. Fetch existing data from Archive
                const archiveSnapshot = await get(ref(db, archivePath));
                const archiveDataRaw = archiveSnapshot.val() || {};
                const existingArchiveUsers = new Set();
                 for (const key in archiveDataRaw) {
                    if (archiveDataRaw[key] && archiveDataRaw[key].user) {
                        existingArchiveUsers.add(archiveDataRaw[key].user);
                    }
                 }
                 if (silent) console.log("Existing Archive Users count:", existingArchiveUsers.size);

                // 2. Filter and Prepare updates
                for (const ticket of allGeneratedTickets) {
                    const username = ticket.username;

                    // Check if already in Archive
                    if (existingArchiveUsers.has(username)) {
                        // if (silent) console.log(`Ticket ${username} already in Archive, skipping.`);
                        skippedCount++;
                    } else {
                        // Add to TicketsTransit
                        const newTransitRef = push(ref(db, transitPath));
                        updates[`${transitPath}/${newTransitRef.key}`] = {
                            category: ticket.profile || 'Uncategorized',
                            password: ticket.password,
                            price: ticket.price,
                            user: username,
                            comment: ticket.comment || '',
                            timestamp: serverTimestamp()
                        };
                        addedToTransitCount++;

                        // Add to TicketsArchive
                        const newArchiveRef = push(ref(db, archivePath));
                        updates[`${archivePath}/${newArchiveRef.key}`] = {
                            category: ticket.profile || 'Uncategorized',
                            password: ticket.password,
                            price: ticket.price,
                            user: username,
                            comment: ticket.comment || '',
                            timestamp: serverTimestamp()
                        };
                        addedToArchiveCount++;
                    }
                }
                const processMsg = `Processed for Transit/Archive: ${addedToTransitCount} added to Transit, ${addedToArchiveCount} added to Archive, ${skippedCount} skipped (already in Archive).`;
                if (silent) console.log(processMsg); else showNotification('info', processMsg);


            } else {
                throw new Error("Invalid primary target specified for saving.");
            }

            // 3. Perform the batch update if there are any changes
            if (Object.keys(updates).length > 0) {
                await update(ref(db), updates);
                const successMsg = `Successfully saved ${Object.keys(updates).length > 1 ? 'updates' : 'update'} to Firebase (${primaryTarget}).`;
                 if (silent) console.log(successMsg); else showNotification('success', successMsg);
                return true;
            } else {
                 const noUpdateMsg = `No new data needed to be saved to Firebase for ${primaryTarget}.`;
                 if (silent) console.log(noUpdateMsg); else showNotification('info', noUpdateMsg);
                 return true; // Indicate success (nothing needed to be done)
            }

        } catch (error) {
            console.error(`Error processing/saving tickets for ${primaryTarget}:`, error);
            showNotification('error', `Failed processing/saving tickets: ${error.message}`);
            return false; // Indicate failure
        } finally {
            if (!silent) {
                hideLoading();
            } else {
                console.log(`Background processing for ${primaryTarget} finished.`);
                // Reset any subtle indicator if used
                // saveTotalBtn.textContent = 'Enregistrer sur TicketsTotal'; // Example Reset
            }
        }
    }

    // --- Event Listeners ---

    // "Enregistrer sur TicketsTotal" Button
    saveTotalBtn.addEventListener('click', async () => {
        // Show loading overlay for this user-initiated action
        showLoading("Fetching categories...");
        try {
            await fetchExistingCategories(); // Get latest categories
            populateCategorySelect(); // Fill the dropdown
            defaultCategoryDisplay.textContent = defaultProfileName; // Show the default profile
            categoryInput.value = ""; // Clear previous input
            categoryInput.placeholder = `Ex: ${defaultProfileName} (ou nouveau nom)`;
            categoryModal.style.display = 'block'; // Show the category selection modal
        } catch(e) {
            showNotification('error', 'Failed to prepare category selection.');
            console.error(e);
        } finally {
            hideLoading(); // Hide loading overlay once category modal is ready or if error
        }
    });

    // "Confirm Category" Button (in category modal)
    confirmCategoryBtn.addEventListener('click', () => {
        let finalCategory = categoryInput.value.trim(); // Prioritize typed input

        if (!finalCategory && categorySelect.value) {
            finalCategory = categorySelect.value; // Fallback to selected dropdown value
        }

        if (!finalCategory) {
            finalCategory = defaultProfileName; // Fallback to default profile name if both are empty
        }

        if (!finalCategory) { // Should only happen if defaultProfileName was also empty/invalid
             showNotification('error', 'Could not determine a category name. Please select or enter one.');
             return;
        }

        categoryModal.style.display = 'none'; // Hide the modal

        // Call the save function with 'TicketsTotal' and the chosen category
        // Show loading overlay for this action. Pass silent=false (default)
        if (confirm(`Save ${allGeneratedTickets.length} ticket(s) to TicketsTotal under category '${finalCategory}'?`)) {
             processAndSaveTickets('TicketsTotal', finalCategory);
        }
    });

    // "Print" Button
    printBtn.addEventListener('click', () => {
        ticketsModal.style.display = 'none'; // Hide the preview modal
        categoryModal.style.display = 'none'; // Ensure category modal is hidden too
        printArea.style.display = 'block';    // Show the formatted print area
        window.print();                      // Trigger browser print dialog

        // Attempt to restore view after printing (browser support varies)
        // Use a timeout as a more reliable cross-browser approach than onafterprint
         setTimeout(() => {
             printArea.style.display = 'none';
             ticketsModal.style.display = 'block';
             console.log("Print dialog closed (estimated), restoring view.");
         }, 1000); // Restore view after 1 second (adjust if needed)

    });

    // "Close" Button (Main Modal)
    closeModalBtn.onclick = function() {
        if (confirm("Close the voucher window? Ensure vouchers are saved or printed if needed.")) {
            window.close(); // Close the browser tab/window
        }
    }

     // --- Initial Setup & Automatic Background Save ---
     document.addEventListener('DOMContentLoaded', async () => {
        // Initialize DB first
        await initializeDb();

        if (totalTicketsGenerated === 0) {
            showNotification('warning', 'No vouchers were generated or found.');
            disableButtons(true);
            if(ticketListContainer) ticketListContainer.innerHTML = '<p style="text-align: center; padding: 20px; color: #555;">No vouchers found matching the criteria.</p>';
        } else {
            // Automatically process for TicketsTransit & TicketsArchive on page load
            // Add a small delay to let the UI render before background task
            await new Promise(resolve => setTimeout(resolve, 200));

            console.log("Starting initial background save to Transit/Archive...");
            // Call the processing function with 'TicketsTransit' and silent=true
            const saved = await processAndSaveTickets('TicketsTransit', null, true); // Pass true for silent

            if (!saved) {
                console.error("Initial background processing for Transit/Archive failed.");
                // Show an error to the user as this background task failed
                showNotification('error', 'Automatic saving to Transit/Archive in background failed. Check console for details. Manual saving might still work.');
                // Consider disabling buttons or showing persistent error state if critical
                // disableButtons(true);
            } else {
                 console.log("Initial background processing for Transit/Archive completed.");
            }
        }
     });

</script>

</body>
</html>