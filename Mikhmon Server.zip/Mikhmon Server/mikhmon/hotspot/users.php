<?php
/*
 *  Copyright (C) 2018 Laksamadi Guko.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

// hide all error
error_reporting(0);
ini_set('max_execution_time', 300); // Increased execution time might be needed

// Assuming session_start() is called by the parent file loading this, if not, add it here.
// session_start();

if (!isset($_SESSION["mikhmon"])) {
  header("Location:../admin.php?id=login");
} else {

  // --- API Connection (should be established by including config/session logic) ---
  // Assuming $API is already connected from the parent script or includes like ../include/config.php, ../lib/routeros_api.class.php etc.
  // Ensure $API is available in this scope.

  // *** STEP 1: Fetch all hotspot profiles and create a price map ***
  $all_profiles_data = $API->comm("/ip/hotspot/user/profile/print");
  $profile_price_map = [];
  if (is_array($all_profiles_data)) {
      foreach ($all_profiles_data as $profile_detail) {
          $profile_name = $profile_detail['name'];
          $price_value = "0"; // Default price for this profile

          if (isset($profile_detail['on-login'])) {
              $ponlogin = $profile_detail['on-login'];
              $ponlogin_parts = explode(",", $ponlogin);
              // Indices 2 (price) and 4 (selling_price) - adjust if your script format differs
              $getprice_from_profile = isset($ponlogin_parts[2]) ? trim($ponlogin_parts[2]) : "0";
              $getsprice_from_profile = isset($ponlogin_parts[4]) ? trim($ponlogin_parts[4]) : "0";

              // Prioritize selling price, then regular price
              if ($getsprice_from_profile != "0" && is_numeric($getsprice_from_profile)) {
                  $price_value = (string)(float)$getsprice_from_profile; // Store as string
              } elseif ($getprice_from_profile != "0" && is_numeric($getprice_from_profile)) {
                  $price_value = (string)(float)$getprice_from_profile; // Store as string
              }
          }
          $profile_price_map[$profile_name] = $price_value; // Map profile name to its price string
      }
  }
  // *** END STEP 1 ***


  // --- Data Fetching Logic based on filters (prof, comm, exp) ---
  $getuser = []; // Filtered users for display
  $all_users_mikhmon_sync = []; // All users for Mikhmon Firebase sync
  $TotalReg = 0; // Count of displayed users after filter
  $counttuser = 0; // Total count before filter (for display in header)

  // Get total count first
  $counttuser = $API->comm("/ip/hotspot/user/print", array("count-only" => ""));

  // Apply filters sequentially, prioritizing comment, then expired, then profile
  if (!empty($comm)) {
    $getuser = $API->comm("/ip/hotspot/user/print", array("?comment" => "$comm"));
  } elseif (!empty($exp)) {
    $getuser = $API->comm("/ip/hotspot/user/print", array("?limit-uptime" => "1s"));
  } elseif (!empty($prof) && $prof != "all") {
    $getuser = $API->comm("/ip/hotspot/user/print", array("?profile" => "$prof"));
  } else { // Default to all if no specific filter
    $getuser = $API->comm("/ip/hotspot/user/print");
  }

  // Fetch ALL users for Mikhmon Firebase sync, regardless of filters
  $all_users_mikhmon_sync_data = $API->comm("/ip/hotspot/user/print");

  // Final count of users actually retrieved after filtering
  $TotalReg = is_array($getuser) ? count($getuser) : 0;

  // Fetch all profiles again just for the dropdown (could potentially reuse $all_profiles_data)
  $getprofile_dropdown = $API->comm("/ip/hotspot/user/profile/print");
  $TotalReg2 = is_array($getprofile_dropdown) ? count($getprofile_dropdown) : 0;


  // --- Prepare data for Javascript (both filtered and all users for Mikhmon sync) ---
  $tickets_for_js = []; // For filtered display and Transit/Archive sync
  $all_mikhmon_tickets_for_js = []; // For full Mikhmon sync

  if (is_array($getuser)){ // Process filtered users for display and Transit/Archive
      for ($i = 0; $i < $TotalReg; $i++) {
        $userdetails = $getuser[$i];
        $uid = $userdetails['.id'];
        $userver = isset($userdetails['server']) ? $userdetails['server'] : 'all';
        $uname = $userdetails['name'];
        $upass = isset($userdetails['password']) ? $userdetails['password'] : '';
        $uprofile = $userdetails['profile'];
        $umacadd = isset($userdetails['mac-address']) ? $userdetails['mac-address'] : '';
        $uuptime_raw = isset($userdetails['uptime']) ? $userdetails['uptime'] : '0s';
        $uuptime = formatDTM($uuptime_raw);
        $ubytesi = formatBytes($userdetails['bytes-in'], 2);
        $ubyteso = formatBytes($userdetails['bytes-out'], 2);
        $ucomment = isset($userdetails['comment']) ? $userdetails['comment'] : '';
        $udisabled = isset($userdetails['disabled']) ? $userdetails['disabled'] : 'false';
        $utimelimit_raw = isset($userdetails['limit-uptime']) ? $userdetails['limit-uptime'] : '';
        $udatalimit_raw = isset($userdetails['limit-bytes-total']) ? $userdetails['limit-bytes-total'] : '';

        // Look up price in the map
        $user_price = isset($profile_price_map[$uprofile]) ? $profile_price_map[$uprofile] : "0";

        // Determine connection status
        $has_connected = ($uuptime_raw !== '0s' && $uuptime_raw !== '00:00:00');

        // Populate $tickets_for_js for filtered view and Transit/Archive
        $tickets_for_js[] = [
            'id' => $uid, // Include ID for deletion check
            'username' => $uname, 'password' => $upass, 'profile' => $uprofile,
            'comment' => $ucomment, 'price' => $user_price, 'has_connected' => $has_connected
        ];
      }
  }


  if (is_array($all_users_mikhmon_sync_data)){ // Process ALL users for Mikhmon sync
      foreach ($all_users_mikhmon_sync_data as $userdetails_mikhmon) {
        $uid_mikhmon = $userdetails_mikhmon['.id'];
        $uname_mikhmon = $userdetails_mikhmon['name'];
        $upass_mikhmon = isset($userdetails_mikhmon['password']) ? $userdetails_mikhmon['password'] : '';
        $uprofile_mikhmon = $userdetails_mikhmon['profile'];
        $ucomment_mikhmon = isset($userdetails_mikhmon['comment']) ? $userdetails_mikhmon['comment'] : '';
        $uuptime_raw_mikhmon = isset($userdetails_mikhmon['uptime']) ? $userdetails_mikhmon['uptime'] : '0s';
        $has_connected_mikhmon = ($uuptime_raw_mikhmon !== '0s' && $uuptime_raw_mikhmon !== '00:00:00');
        $user_price_mikhmon = isset($profile_price_map[$uprofile_mikhmon]) ? $profile_price_map[$uprofile_mikhmon] : "0";

        // Populate $all_mikhmon_tickets_for_js for full Mikhmon sync
        $all_mikhmon_tickets_for_js[] = [
            'id' => $uid_mikhmon,
            'username' => $uname_mikhmon, 'password' => $upass_mikhmon, 'profile' => $uprofile_mikhmon,
            'comment' => $ucomment_mikhmon, 'price' => $user_price_mikhmon, 'has_connected' => $has_connected_mikhmon
        ];
      }
  }


}
?>

<div class="row">
<div class="col-12">
<div class="card">
<div class="card-header">
    <h3><i class="fa fa-users"></i> <?= $_users ?>
      <span style="font-size: 14px">
         <!-- Links -->
           |   <a href="./?hotspot-user=add&session=<?= $session; ?>" title="Add User"><i class="fa fa-user-plus"></i> <?= $_add ?></a>
          |   <a href="./?hotspot-user=generate&session=<?= $session; ?>" title="Generate User"><i class="fa fa-users"></i> <?= $_generate ?></a>
           |   <a href="<?= str_replace("=users", "=export-users", $url); ?>&export=script" title="Download User List as Mikrotik Script"><i class="fa fa-download"></i> Script</a>  |   <a href="<?= str_replace("=users", "=export-users", $url); ?>&export=csv" title="Download User List as CSV"><i class="fa fa-download"></i> CSV</a>
        </span>   
        <small id="loader" style="display: none;" ><i><i class='fa fa-circle-o-notch fa-spin'></i> <?= $_processing ?> </i></small>
    </h3>
</div>
<div class="card-body">
  <div class="row">
   <div class="col-6 pd-t-5 pd-b-5">
      <!-- Filter Inputs -->
       <div class="input-group">
           <div class="input-group-4 col-box-4">
               <input id="filterTable" type="text" style="padding:5.8px;" class="group-item group-item-l" placeholder="<?= $_search ?>">
           </div>
           <div class="input-group-4 col-box-4">
               <select style="padding:5px;" class="group-item group-item-m" onchange="location = this.value; loader()" title="Filter by Profile">
                   <option value='./?hotspot=users&profile=all&session=<?= $session; ?>'><?= $_profile ?> (<?= $_show_all ?>)</option>
                   <?php
                   if(is_array($getprofile_dropdown)){
                       foreach($getprofile_dropdown as $profile_dd) {
                           $selected = ($prof == $profile_dd['name']) ? "selected" : "";
                           echo "<option value='./?hotspot=users&profile=" . htmlspecialchars($profile_dd['name']) . "&session=" . $session . "' ".$selected.">" . htmlspecialchars($profile_dd['name']) . "</option>";
                       }
                   }
                   ?>
               </select>
           </div>
           <div class="input-group-4 col-box-4">
               <select style="padding:5px;" class="group-item group-item-r" id="comment" name="comment" onchange="location = './?hotspot=users&comment='+ this.value +'&session=<?= $session;?>';">
                   <option value=''><?= $_comment ?></option>
                   <?php
                   // Comment dropdown logic (consider optimizing if very slow)
                   $all_users_for_comments = $API->comm("/ip/hotspot/user/print");
                   $unique_comments = [];
                   if(is_array($all_users_for_comments)){
                       foreach($all_users_for_comments as $user_data) {
                           $ucomment = $user_data['comment'];
                           if(!empty($ucomment)){ $unique_comments[$ucomment] = isset($unique_comments[$ucomment]) ? $unique_comments[$ucomment] + 1 : 1; }
                       }
                   }
                   arsort($unique_comments);
                   foreach ($unique_comments as $tcomment => $value) {
                       $selected = ($comm == $tcomment) ? "selected" : "";
                       echo "<option value='" . htmlspecialchars($tcomment) . "' ".$selected." >". htmlspecialchars($tcomment)." [".$value. "]</option>";
                   }
                   ?>
               </select>
           </div>
       </div>
   </div>

  <div class="col-6 text-right"> <!-- Aligned buttons to the right -->
    <!-- Buttons for Deletion / Printing -->
    <?php if (!empty($comm)) { ?>
        <button class="btn bg-red" onclick="if(confirm('Are you sure to delete username by comment (<?= htmlspecialchars($comm); ?>)?')){loadpage('./?remove-hotspot-user-by-comment=<?= urlencode($comm); ?>&session=<?= $session; ?>');loader();}else{}" title="Remove user by comment <?= htmlspecialchars($comm); ?>">  <i class="fa fa-trash"></i> <?= $_by_comment ?></button>

        <!-- Added Print Buttons (Appear only when $comm is set) -->
        <script>
          function openPrintWindow(params) {
            var url = './voucher/print.php?id=<?= urlencode($comm) ?>&session=<?= $session ?>' + params;
            var win = window.open(url, '_blank');
            if(win){ win.focus(); } else { alert('Popup blocked? Please allow popups for this site.');}
          }
        </script>
        <button class="btn bg-primary" title='Print Default (<?= htmlspecialchars($comm); ?>)' onclick="openPrintWindow('&qr=no');"><i class="fa fa-print"></i></button>
        <button class="btn bg-primary" title='Print QR (<?= htmlspecialchars($comm); ?>)' onclick="openPrintWindow('&qr=yes');"><i class="fa fa-qrcode"></i></button>
        <button class="btn bg-primary" title='Print Small (<?= htmlspecialchars($comm); ?>)' onclick="openPrintWindow('&small=yes');"><i class="fa fa-print"></i> Imprimer</button>

    <?php } else if ($exp == "1") { ?>
        <button class="btn bg-red" onclick="if(confirm('Are you sure to delete users?')){loadpage('./?remove-hotspot-user-expired=1&session=<?= $session; ?>');loader();}else{}" title="Remove user expired">  <i class="fa fa-trash"></i> Expired Users</button>
    <?php } ?>
  </div>
</div>
<div class="overflow mr-t-10 box-bordered" style="max-height: 75vh">
<table id="dataTable" class="table table-bordered table-hover text-nowrap">
  <thead>
  <tr>
    <!-- Display filtered count in table header -->
    <th style="min-width:50px;" class="align-middle text-center" id="cuser"><?= $TotalReg; ?> / <?= $counttuser ?></th>
    <th style="min-width:50px;" class="pointer" title="Click to sort"><i class="fa fa-sort"></i> Server</th>
    <th class="pointer" title="Click to sort"><i class="fa fa-sort"></i> <?= $_name ?></th>
    <th>Print</th>
    <th class="pointer" title="Click to sort"><i class="fa fa-sort"></i> <?= $_profile ?></th>
    <th class="pointer" title="Click to sort"><i class="fa fa-sort"></i> Mac Address</th>
    <th class="text-right align-middle pointer" title="Click to sort"><i class="fa fa-sort"></i> <?= $_uptime_user ?></th>
    <th class="text-right align-middle pointer" title="Click to sort"><i class="fa fa-sort"></i> Bytes In</th>
    <th class="text-right align-middle pointer" title="Click to sort"><i class="fa fa-sort"></i> Bytes Out</th>
    <th class="pointer" title="Click to sort"><i class="fa fa-sort"></i> <?= $_comment ?></th>
    </tr>
  </thead>
  <tbody id="tbody">
<?php
if (is_array($getuser)){ // Ensure $getuser is iterable
    for ($i = 0; $i < $TotalReg; $i++) {
      $userdetails = $getuser[$i];
      $uid = $userdetails['.id'];
      $userver = isset($userdetails['server']) ? $userdetails['server'] : 'all';
      $uname = $userdetails['name'];
      $upass = isset($userdetails['password']) ? $userdetails['password'] : '';
      $uprofile = $userdetails['profile'];
      $umacadd = isset($userdetails['mac-address']) ? $userdetails['mac-address'] : '';
      $uuptime_raw = isset($userdetails['uptime']) ? $userdetails['uptime'] : '0s';
      $uuptime = formatDTM($uuptime_raw);
      $ubytesi = formatBytes($userdetails['bytes-in'], 2);
      $ubyteso = formatBytes($userdetails['bytes-out'], 2);
      $ucomment = isset($userdetails['comment']) ? $userdetails['comment'] : '';
      $udisabled = isset($userdetails['disabled']) ? $userdetails['disabled'] : 'false';
      $utimelimit_raw = isset($userdetails['limit-uptime']) ? $userdetails['limit-uptime'] : '';
      $udatalimit_raw = isset($userdetails['limit-bytes-total']) ? $userdetails['limit-bytes-total'] : '';

      // Look up price in the map
      $user_price = isset($profile_price_map[$uprofile]) ? $profile_price_map[$uprofile] : "0";

      // Determine connection status
      $has_connected = ($uuptime_raw !== '0s' && $uuptime_raw !== '00:00:00');


      // --- Display Table Row ---
      $utimelimit_display = ''; $udatalimit_display = '';
      if( $utimelimit_raw == '1s') { $utimelimit_display = ' <span class="text-danger">expired</span>'; }
      else if (!empty($utimelimit_raw)){ $utimelimit_display = ' ' . htmlspecialchars($utimelimit_raw); }
      if(!empty($udatalimit_raw)) { $udatalimit_display = ' '.formatBytes($udatalimit_raw, 2); }

      echo "<tr>";
      // Actions
      echo "<td style='text-align:center;'>";
      echo "<i class='fa fa-minus-square text-danger pointer' onclick=\"if(confirm('Are you sure to delete username (".htmlspecialchars($uname, ENT_QUOTES).")?')){loadpage('./?remove-hotspot-user=".urlencode($uid)."&session=".$session."')}else{}\" title='Remove ".htmlspecialchars($uname, ENT_QUOTES)."'></i>";
      echo "   ";
      if ($udisabled == "true") { $uriprocess = "'./?enable-hotspot-user=" . urlencode($uid) . "&session=" . $session."'"; echo '<span class="text-warning pointer" title="Enable User ' . htmlspecialchars($uname, ENT_QUOTES) . '"  onclick="loadpage('.$uriprocess.')"><i class="fa fa-lock "></i></span>'; }
      else { $uriprocess = "'./?disable-hotspot-user=" . urlencode($uid) . "&session=" . $session."'"; echo '<span class="pointer" title="Disable User ' . htmlspecialchars($uname, ENT_QUOTES) . '"  onclick="loadpage('.$uriprocess.')"><i class="fa fa-unlock "></i></span>'; }
      echo "</td>";
      // Details
      echo "<td>" . htmlspecialchars($userver) . "</td>";
      if ($uname == $upass && !empty($upass)) { $usermode = "vc"; } else { $usermode = "up"; }
      // Individual print popups (can be kept or removed if batch print is preferred)
      $popup = "javascript:window.open('./voucher/print.php?user=" . $usermode . "-" . urlencode($uname) . "&qr=no&session=" . $session . "','_blank','width=320,height=550').print();";
      $popupQR = "javascript:window.open('./voucher/print.php?user=" . $usermode . "-" . urlencode($uname) . "&qr=yes&session=" . $session . "','_blank','width=320,height=550').print();";
      echo "<td><a title='Open User " . htmlspecialchars($uname) . "' href=./?hotspot-user=" . urlencode($uid) . "&session=" . $session . "><i class='fa fa-edit'></i> " . htmlspecialchars($uname) . " </a></td>";
      echo '<td class="text-center"><a title="Print ' . htmlspecialchars($uname) . '" href="' . $popup . '"><i class="fa fa-print"></i></a>   <a title="Print QR ' . htmlspecialchars($uname) . '" href="' . $popupQR . '"><i class="fa fa-qrcode"></i> </a></td>';
      echo "<td>" . htmlspecialchars($uprofile) . "</td>";
      echo "<td style=' text-align:left'>" . htmlspecialchars($umacadd) . "</td>";
      echo "<td style=' text-align:right'>" . $uuptime . "</td>";
      echo "<td style=' text-align:right'>" . $ubytesi . "</td>";
      echo "<td style=' text-align:right'>" . $ubyteso . "</td>";
      // Comment Column
      echo "<td>";
      $comment_display = htmlspecialchars($ucomment);
      if ($uname == "default-trial") {}
      else if (!empty($ucomment) && (substr($ucomment,0,3) == "vc-" || substr($ucomment,0,3) == "up-")) { $comment_display = "<a href=./?hotspot=users&comment=" . urlencode($ucomment) . "&session=" . $session . " title='Filter by " . htmlspecialchars($ucomment) . "'><i class='fa fa-search'></i> ". htmlspecialchars($ucomment)."</a>"; }
      else if ($utimelimit_display == ' <span class="text-danger">expired</span>') { $comment_display = "<a href=./?hotspot=users&profile=all&exp=1&session=" . $session . " title='Filter by expired'><i class='fa fa-search'></i> " . htmlspecialchars($ucomment)."</a>"; }
      echo $comment_display . $udatalimit_display . $utimelimit_display;
      echo "</td>";
      echo "</tr>";
    } // End for loop
} // End check if $getuser is array
?>
  </tbody>
</table>
</div>
</div>
</div>
</div>
</div>

<!-- Loading Overlay HTML - Keep it in case you want to re-enable loading display for other operations -->
<div id="loadingOverlay" style="position: fixed; top: 0; left: 0; width: 100%; height: 100%; background-color: rgba(0, 0, 0, 0.7); display: none; justify-content: center; align-items: center; z-index: 1001; color: white; font-size: 1.2em;">Processing...<div style="content: ''; width: 40px; height: 40px; border: 4px solid #f3f3f3; border-top: 4px solid #3498db; border-radius: 50%; animation: spin 1s linear infinite; margin-left: 15px;"></div></div>
<style> @keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } } </style>

<!-- JavaScript Section for Firebase -->
<script type="module">
    // --- Import Firebase Modules ---
    import { getActiveDatabase } from '../voucher/firebase-config-manager.js'; // Adjust path as needed
    import { getDatabase, ref, get, update, push, serverTimestamp, remove } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-database.js";

    // --- Configuration ---
    const allGeneratedTickets = <?= json_encode($tickets_for_js); ?>; // Filtered tickets for Transit/Archive
    const allMikhmonTickets = <?= json_encode($all_mikhmon_tickets_for_js); ?>; // ALL tickets for Mikhmon sync
    const totalTicketsGenerated = <?= $TotalReg ?>; // Count after filters are applied (for filtered tickets display)
    const totalMikhmonTickets = <?= $counttuser ?>; // Total count of all tickets (for Mikhmon sync)


    // --- DOM Elements ---
    const loadingOverlay = document.getElementById('loadingOverlay'); // Keep for potential future use

    // --- Helper Functions ---
    // Modified to be no-ops for discreet background sync
    function showLoading(message = "Processing...") {
        // loadingOverlay.textContent = message;  // No UI update
        // loadingOverlay.style.display = 'flex'; // No UI update
    }
    function hideLoading() {
        // loadingOverlay.style.display = 'none';  // No UI update
    }
    function showNotification(type, message) {
        if (type === 'error') {
            alert(`[${type.toUpperCase()}] ${message}`); // Keep alerts for errors
        } else {
            console.log(`[${type.toUpperCase()}] ${message}`); // Use console.log for info/success messages
        }
    }

    /**
     * Processes and saves tickets to TicketsTransit & TicketsArchive (based on filtered list),
     * and synchronizes ALL UNUSED tickets to TicketsMikhmon, removing used ones.
     */
    let currentUserId = localStorage.getItem('firebaseUserId');

    async function processAndSaveTickets() {
        if (!currentUserId || currentUserId === 'XXXXXXXXXXX') {
            showNotification('error', 'Firebase User ID is not configured correctly.');
            hideLoading(); return false;
        }

        showLoading(`Synchronisation des tickets...`); // Still call showLoading, but it's a no-op visually

        try {
            const db = await getActiveDatabase();
            if (!db) throw new Error("Failed to get active Firebase database instance.");

            const updates = {};
            let addedToTransitCount = 0;
            let addedToArchiveCount = 0;
            let skippedTransitCount = 0;
            let addedToMikhmonCount = 0;
            let updatedMikhmonCount = 0;
            let removedFromMikhmonCount = 0;

            const transitPath = `users-data/${currentUserId}/TicketsTransit`;
            const archivePath = `users-data/${currentUserId}/TicketsArchive`;
            const mikhmonPath = `users-data/${currentUserId}/TicketsMikhmon`;

            // Fetch existing data once
            const [archiveSnapshot, transitSnapshot, mikhmonSnapshot] = await Promise.all([
                get(ref(db, archivePath)),
                get(ref(db, transitPath)),
                get(ref(db, mikhmonPath))
            ]);
            const archiveDataRaw = archiveSnapshot.val() || {};
            const transitDataRaw = transitSnapshot.val() || {};
            const mikhmonDataRaw = mikhmonSnapshot.val() || {};

            const existingArchiveUsers = new Set(Object.values(archiveDataRaw).map(ticket => ticket.user));
            const existingTransitUsers = new Set(Object.values(transitDataRaw).map(ticket => ticket.user));
            const existingMikhmonUsers = new Map(Object.entries(mikhmonDataRaw).map(([key, ticket]) => [ticket.username, key])); // Map username to key

            // --- Process Filtered Tickets for Transit/Archive (same as before) ---
            if (allGeneratedTickets && allGeneratedTickets.length > 0) {
                const currentFilteredUsersInPHP = new Set();
                for (const ticket of allGeneratedTickets) {
                    const username = ticket.username;
                    const hasConnected = ticket.has_connected;
                    currentFilteredUsersInPHP.add(username);

                    let shouldSkipTransit = false;
                    let shouldArchive = false;

                    if (!existingArchiveUsers.has(username)) {
                        shouldArchive = true;
                    }
                    if (hasConnected || existingArchiveUsers.has(username) || existingTransitUsers.has(username)) {
                        shouldSkipTransit = true;
                        if (existingTransitUsers.has(username) && !existingArchiveUsers.has(username)){
                             shouldArchive = true;
                        }
                    }

                    if (shouldArchive) {
                         const newArchiveRef = push(ref(db, archivePath));
                         updates[`${archivePath}/${newArchiveRef.key}`] = {
                             category: ticket.profile || 'Uncategorized',
                             password: ticket.password || '',
                             price: ticket.price,
                             user: username,
                             comment: ticket.comment || '',
                             timestamp: serverTimestamp()
                         };
                         addedToArchiveCount++;
                     }

                    if (!shouldSkipTransit) {
                        const newTransitRef = push(ref(db, transitPath));
                        updates[`${transitPath}/${newTransitRef.key}`] = {
                            category: ticket.profile || 'Uncategorized',
                            password: ticket.password || '',
                             price: ticket.price,
                            user: username,
                            comment: ticket.comment || '',
                            timestamp: serverTimestamp()
                        };
                        addedToTransitCount++;
                    } else {
                       if (!existingArchiveUsers.has(username) && !existingTransitUsers.has(username) && hasConnected){ skippedTransitCount++; }
                       else if (existingArchiveUsers.has(username) || existingTransitUsers.has(username)) { skippedTransitCount++; }
                    }
                }
            }


            // --- Process ALL Tickets for TicketsMikhmon Sync ---
            if (allMikhmonTickets && allMikhmonTickets.length > 0) {
                const currentMikhmonUsersInPHP = new Set();
                for (const ticket of allMikhmonTickets) {
                    const username = ticket.username;
                    const hasConnected = ticket.has_connected;
                    currentMikhmonUsersInPHP.add(username);

                    // *** TicketsMikhmon Synchronization Logic ***
                    const mikhmonTicketData = {
                        id: ticket.id,
                        category: ticket.profile || 'Uncategorized',
                        password: ticket.password || '',
                        price: ticket.price,
                        username: username,
                        comment: ticket.comment || '',
                        has_connected: hasConnected, // Important: Keep current connection status
                        timestamp: serverTimestamp()
                    };

                    if (!hasConnected) { // ADD/UPDATE only if NOT connected yet - NEW CONDITION
                        if (existingMikhmonUsers.has(username)) {
                            // User exists and NOT connected, update data
                            const existingKey = existingMikhmonUsers.get(username);
                            updates[`${mikhmonPath}/${existingKey}`] = mikhmonTicketData;
                            updatedMikhmonCount++;
                        } else {
                            // User doesn't exist and NOT connected, add new
                            const newMikhmonRef = push(ref(db, mikhmonPath));
                            updates[`${mikhmonPath}/${newMikhmonRef.key}`] = mikhmonTicketData;
                            addedToMikhmonCount++;
                        }
                    }
                }

                // *** Handle Deletions from TicketsMikhmon (Remove CONNECTED tickets) ***
                const usersToRemoveFromMikhmon = [];
                for (const usernameInFirebase of existingMikhmonUsers.keys()) {
                    const existingTicketInFirebase = mikhmonDataRaw[existingMikhmonUsers.get(usernameInFirebase)]; //Get full ticket data
                    let isStillInMikrotik = false;
                    for (const phpTicket of allMikhmonTickets) { // Check if still in Mikrotik user list
                        if (phpTicket.username === usernameInFirebase) {
                            isStillInMikrotik = true;
                            if (phpTicket.has_connected) { // If now connected in Mikrotik, remove from Firebase
                                usersToRemoveFromMikhmon.push(existingMikhmonUsers.get(usernameInFirebase));
                            }
                            break; // Found in Mikrotik, no need to continue inner loop
                        }
                    }
                    if (!isStillInMikrotik) { // If not found in current Mikrotik user list, remove (ticket deleted from Mikrotik)
                        usersToRemoveFromMikhmon.push(existingMikhmonUsers.get(usernameInFirebase));
                    } else if (existingTicketInFirebase && existingTicketInFirebase.has_connected === false && isStillInMikrotik) {
                        //Ticket exists in firebase and Mikrotik, but still marked as not connected in Firebase, check if it's now connected in Mikrotik on this sync
                        let currentMikrotikStatus = false;
                        for (const phpTicket of allMikhmonTickets) {
                            if (phpTicket.username === usernameInFirebase && phpTicket.has_connected) {
                                currentMikrotikStatus = true;
                                break;
                            }
                        }
                        if (currentMikrotikStatus) {
                            usersToRemoveFromMikhmon.push(existingMikhmonUsers.get(usernameInFirebase)); //Remove if now connected
                        }

                    }

                }


                usersToRemoveFromMikhmon.forEach(key => {
                    updates[`${mikhmonPath}/${key}`] = null;
                    removedFromMikhmonCount++;
                });
            }


            // Provide summary notification (console.log for info, alert for error)
            let notificationMessage = `Tickets synchronisés en arrière-plan. `;
            if (addedToTransitCount > 0) notificationMessage += `${addedToTransitCount} Transit, `;
            if (addedToArchiveCount > 0) notificationMessage += `${addedToArchiveCount} Archive, `;
            if (skippedTransitCount > 0) notificationMessage += `${skippedTransitCount} Transit ignorés (connecté/duplicata), `;
            if (addedToMikhmonCount > 0) notificationMessage += `${addedToMikhmonCount} Mikhmon ajoutés, `;
            if (updatedMikhmonCount > 0) notificationMessage += `${updatedMikhmonCount} Mikhmon mis à jour, `;
            if (removedFromMikhmonCount > 0) notificationMessage += `${removedFromMikhmonCount} Mikhmon supprimés.`;


            if (addedToTransitCount > 0 || addedToArchiveCount > 0 || skippedTransitCount > 0 || addedToMikhmonCount > 0 || updatedMikhmonCount > 0 || removedFromMikhmonCount > 0) {
                showNotification('info', notificationMessage); // console.log for info now
            } else {
                 console.log('Aucun changement détecté pour la synchronisation Firebase.'); // console.log
            }

            // Perform the batch update
            if (Object.keys(updates).length > 0) {
                await update(ref(db), updates);
            }
            return true;

        } catch (error) {
            console.error(`Erreur lors du traitement/enregistrement des tickets Firebase en arrière-plan:`, error);
            showNotification('error', `Échec de la synchronisation Firebase: ${error.message}`); // Alert for errors
            return false;
        } finally {
            hideLoading(); // Still call hideLoading, but it's a no-op visually
        }
    }

    // --- Initial Setup: Run sync in background on page load ---
    if (totalMikhmonTickets > 0) {
        window.addEventListener('DOMContentLoaded', () => { // Removed async and await to run in background
            processAndSaveTickets(); // Run in background - no await
            // No error handling here for background sync, errors are logged and alerted via showNotification('error', ...)
        });
    } else {
         console.log("Aucun utilisateur trouvé au chargement de la page (total), synchronisation Firebase (Mikhmon) ignorée."); // console.log
    }

</script>