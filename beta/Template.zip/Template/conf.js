var config = {

loginvc : "Masukkan Kode Voucher kemudian klik Connect.",
loginup : "Masukkan Username dan Password <br> kemudian klik Connect.",
voucherCode : "Kode Voucher",
setCase : "none", // lowercase, uppercase or none
defaultMode : "voucher", // voucher or member
theme : "default", // default, dark, lite

// status expire

url : "https://demo.mikhmon.online", // url server Mikhmon
SessionName : "demo", 

}
